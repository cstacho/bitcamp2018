import webview
# Create a resizable webview window with 800x600 dimensio
webview.create_window("ArkFund", "http://127.0.0.1:8000/", width=1400,height=800, resizable=False, fullscreen=False)