from django.apps import AppConfig


class ArkFundConfig(AppConfig):
    name = 'ark_fund'
