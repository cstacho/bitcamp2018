create table campaigns(key varchar(50) primary key, name varchar(500), description varchar(5000), goal integer, created_on timestamp);
